#!/bin/bash
# VideoGrab Installation (macOS). Laeuft automatisch beim ersten Start oder manuell: bash install.sh
set -e
APP="$(cd "$(dirname "$0")" && pwd)"
BUNDLE="$(cd "$APP/../.." && pwd)"           # .../VideoGrab.app/Contents
APPDIR="$(dirname "$BUNDLE")"                # .../VideoGrab.app
DATA="$HOME/Library/Application Support/VideoGrab"
echo "== VideoGrab Installation =="
echo

if ! command -v brew >/dev/null 2>&1 && [ ! -x /opt/homebrew/bin/brew ] && [ ! -x /usr/local/bin/brew ]; then
  echo "Homebrew fehlt. Installiere Homebrew (fragt nach deinem Mac-Passwort) ..."
  /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
fi
eval "$(/opt/homebrew/bin/brew shellenv 2>/dev/null || /usr/local/bin/brew shellenv)"
# Apple Silicon: alles ausdruecklich im ARM-Modus, auch wenn das Terminal unter Rosetta laeuft
ARCH=""; [ -d /opt/homebrew ] && ARCH="arch -arm64"

echo "Installiere ffmpeg, yt-dlp, gallery-dl, python, poppler ..."
$ARCH brew install ffmpeg yt-dlp gallery-dl python poppler 2>&1 | grep -Ev "^(==>|Already|Warning: .* already installed)" || true

echo "Richte Python-Umgebung ein ..."
mkdir -p "$DATA"
if [ ! -x "$DATA/venv/bin/python3" ]; then
  $ARCH "$(brew --prefix)/bin/python3" -m venv "$DATA/venv"
fi
"$DATA/venv/bin/pip" install -q -U pip pywebview pyobjc-framework-Cocoa pyobjc-framework-WebKit pypdf

echo "Setze Rechte und entferne Quarantäne-Markierung ..."
chmod +x "$BUNDLE/MacOS/VideoGrab" "$APP/install.sh" "$APP/videograb_app.py" 2>/dev/null || true
xattr -cr "$APPDIR" 2>/dev/null || true

if [ "$(dirname "$APPDIR")" != "/Applications" ] && [ "$(dirname "$APPDIR")" != "$HOME/Applications" ]; then
  echo
  read -p "VideoGrab.app nach /Applications verschieben? [J/n] " ans
  if [[ ! "$ans" =~ ^[nN] ]]; then
    rm -rf "/Applications/VideoGrab.app"
    cp -R "$APPDIR" "/Applications/VideoGrab.app" && APPDIR="/Applications/VideoGrab.app" && echo "Liegt jetzt in /Applications."
  fi
fi

echo
echo "Fertig. VideoGrab wird gestartet. Tipp: Icon im Dock mit Rechtsklick > Optionen > Im Dock behalten."
sleep 1
open "$APPDIR"
